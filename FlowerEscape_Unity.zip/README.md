# Flower Escape - Gameplay UI (Unity)

## Cai dat
1. Tao project Unity moi (2D hoac URP, Unity 2021.3+ / Unity 6 deu duoc).
2. Copy thu muc `Assets` trong zip nay de len `Assets` cua project.
3. Doi Unity compile xong, chon menu **Flower Escape > Build Gameplay Scene**.
   Scene `Assets/Scenes/Gameplay.unity` se duoc tao va them vao Build Settings.
4. Nhan Play.

## Test responsive 9:21 va 3:4
Game view > dropdown ti le > dau `+` > Type: Aspect Ratio
- 9 : 21
- 3 : 4
(Hoac chon thiet bi Simulator.) Bo cuc tu doi: panel duoi/khu combat chia lai theo ti le,
luoi gear tu tinh lai kich thuoc o vuong, Safe Area tu co.

## Hai trang thai
- Combat: 3 nut skill + nut XEP GEAR. Gear tren luoi tang sat thuong.
- Xep gear: luoi 4x3 + kho gear 6 o. Keo tha gear (tha vao o co gear se doi cho).
  XOA HET tra gear ve kho, XONG quay lai combat.

## Gan asset tu Figma
Export PNG tu Figma, dat vao `Assets/UI/Sprites/` dung ten duoi day, chon Texture Type = Sprite (2D and UI).
Voi nut/panel/slot nen dat 9-slice trong Sprite Editor. Sau do chay lai menu Build Gameplay Scene.

bg, hud, panel, ground, coin, hero, enemy, slot,
btn_main, btn_alt, btn_skill, btn_pause,
gear_1 ... gear_5

Ten khac / them gear: sua cac chuoi key trong `Assets/Scripts/Editor/FlowerEscapeUIBuilder.cs`.
