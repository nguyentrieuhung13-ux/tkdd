#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Menu: Flower Escape > Build Gameplay Scene
/// Dung toan bo UI man gameplay (Combat + Xep gear). Neu co sprite trong
/// Assets/UI/Sprites voi dung ten (xem README) thi tu dong dung sprite do.
/// </summary>
public static class FlowerEscapeUIBuilder
{
    const string SpriteDir = "Assets/UI/Sprites/";
    static Font _font;

    static readonly Color BgCol = Hex("2B1B3D"), HudCol = Hex("1F1330"), PanelCol = Hex("3A2655"),
        SlotCol = Hex("52397A"), BtnCol = Hex("F2A93B"), BtnAlt = Hex("6C4BA6"),
        HeroCol = Hex("5BD16B"), EnemyCol = Hex("E4545A"), BarBg = Hex("00000099"), White = Color.white;

    [MenuItem("Flower Escape/Build Gameplay Scene")]
    public static void Build()
    {
        _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (_font == null) _font = Resources.GetBuiltinResource<Font>("Arial.ttf");

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var cam = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
        cam.tag = "MainCamera";
        var c = cam.GetComponent<Camera>(); c.clearFlags = CameraClearFlags.SolidColor; c.backgroundColor = BgCol;

        var es = new GameObject("EventSystem", typeof(EventSystem));
        var inputType = System.Type.GetType("UnityEngine.InputSystem.UI.InputSystemUIInputModule, Unity.InputSystem");
        if (inputType != null) es.AddComponent(inputType); else es.AddComponent<StandaloneInputModule>();

        // ---------- Canvas ----------
        var canvasGo = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGo.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1080, 1920);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        var bg = Panel("Background", canvasGo.transform, BgCol, 0, 0, 1, 1, "bg");

        var safe = Rect("SafeArea", canvasGo.transform);
        Anchor(safe, 0, 0, 1, 1);
        safe.gameObject.AddComponent<SafeAreaFitter>();

        // ---------- Top HUD ----------
        var hud = Panel("TopHUD", safe, HudCol, 0, 0.93f, 1, 1, "hud");
        var stageLbl = Label(hud, "MAN 1", 46, White, TextAnchor.MiddleCenter, 0.3f, 0, 0.7f, 1, "StageLabel");
        var stateLbl = Label(hud, "CHIEN DAU", 26, Hex("FFD27A"), TextAnchor.LowerCenter, 0.3f, 0, 0.7f, 0.35f, "StateLabel");
        var coinIcon = Panel("CoinIcon", hud, Hex("FFC83D"), 0.04f, 0.25f, 0.04f, 0.75f, "coin");
        coinIcon.sizeDelta = new Vector2(56, 56); coinIcon.anchorMin = coinIcon.anchorMax = new Vector2(0.06f, 0.5f);
        coinIcon.anchoredPosition = Vector2.zero;
        var coinLbl = Label(hud, "0", 40, White, TextAnchor.MiddleLeft, 0.11f, 0, 0.3f, 1, "CoinLabel");
        var pause = Btn(hud, "PauseButton", "II", BtnAlt, 0.84f, 0.15f, 0.96f, 0.85f, "btn_pause");

        // ---------- Combat area ----------
        var combat = Rect("CombatArea", safe);
        Anchor(combat, 0, 0.32f, 1, 0.93f);
        Panel("Ground", combat, Hex("3F7A4A"), 0, 0, 1, 0.3f, "ground");
        var heroFill = Character(combat, "Hero", "HOA", HeroCol, 0.2f, 230, "hero");
        var enemyFills = new RectTransform[3];
        float[] ex = { 0.52f, 0.70f, 0.88f };
        for (int i = 0; i < 3; i++) enemyFills[i] = Character(combat, "Enemy" + (i + 1), "QUAI", EnemyCol, ex[i], 150, "enemy");

        // ---------- Bottom panel ----------
        var bottom = Panel("BottomPanel", safe, PanelCol, 0, 0, 1, 0.32f, "panel");

        // Combat state panel
        var cp = Rect("CombatPanel", bottom); Anchor(cp, 0, 0, 1, 1);
        var power = Label(cp, "Luc gear: 0", 34, White, TextAnchor.MiddleCenter, 0.05f, 0.72f, 0.95f, 0.98f, "PowerLabel");
        for (int i = 0; i < 3; i++)
            Btn(cp, "Skill" + (i + 1), "SKILL " + (i + 1), BtnAlt, 0.05f + i * 0.32f, 0.36f, 0.31f + i * 0.32f, 0.70f, "btn_skill");
        var openGear = Btn(cp, "OpenGearButton", "XEP GEAR", BtnCol, 0.05f, 0.05f, 0.95f, 0.30f, "btn_main");

        // Gear state panel
        var gp = Rect("GearPanel", bottom); Anchor(gp, 0, 0, 1, 1);
        Label(gp, "XEP GEAR - keo tha vao o", 34, White, TextAnchor.MiddleCenter, 0.05f, 0.92f, 0.95f, 1f, "GearTitle");

        var boardRt = Rect("GearBoard", gp); Anchor(boardRt, 0.04f, 0.33f, 0.96f, 0.91f);
        var grid = boardRt.gameObject.AddComponent<GridLayoutGroup>();
        var board = boardRt.gameObject.AddComponent<GearBoard>(); board.cols = 4; board.rows = 3;
        for (int i = 0; i < 12; i++) NewSlot(boardRt, "BoardSlot" + (i + 1), false);

        Label(gp, "KHO GEAR", 26, Hex("FFD27A"), TextAnchor.MiddleLeft, 0.05f, 0.255f, 0.5f, 0.33f, "InvTitle");
        var invRt = Rect("Inventory", gp); Anchor(invRt, 0.04f, 0.13f, 0.96f, 0.26f);
        invRt.gameObject.AddComponent<GridLayoutGroup>();
        var inv = invRt.gameObject.AddComponent<GearBoard>(); inv.cols = 6; inv.rows = 1; inv.spacing = 8;
        Color[] gearCols = { Hex("4FC3F7"), Hex("81C784"), Hex("FFB74D"), Hex("BA68C8"), Hex("F06292") };
        for (int i = 0; i < 6; i++)
        {
            var slot = NewSlot(invRt, "InvSlot" + (i + 1), true);
            if (i < 5) NewGear(slot, i + 1, gearCols[i]);
        }
        var clear = Btn(gp, "ClearGearButton", "XOA HET", BtnAlt, 0.05f, 0.01f, 0.40f, 0.11f, "btn_alt");
        var done = Btn(gp, "DoneGearButton", "XONG", BtnCol, 0.45f, 0.01f, 0.95f, 0.11f, "btn_main");

        // ---------- Controllers ----------
        var ctrlGo = new GameObject("GameController");
        var ui = ctrlGo.AddComponent<GameUIController>();
        ui.combatArea = combat; ui.bottomPanel = bottom; ui.combatPanel = cp.gameObject; ui.gearPanel = gp.gameObject;
        ui.openGearButton = openGear; ui.doneGearButton = done; ui.clearGearButton = clear; ui.stateLabel = stateLbl;

        var demo = ctrlGo.AddComponent<CombatDemo>();
        demo.ui = ui; demo.heroFill = heroFill; demo.enemyFills = enemyFills;
        demo.stageLabel = stageLbl; demo.powerLabel = power; demo.coinLabel = coinLbl;

        gp.gameObject.SetActive(false);   // bat dau o trang thai Combat

        System.IO.Directory.CreateDirectory("Assets/Scenes");
        const string path = "Assets/Scenes/Gameplay.unity";
        EditorSceneManager.SaveScene(scene, path);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(path, true) };
        Debug.Log("Da tao " + path + ". Mo Game view, them aspect 9:21 va 3:4 de kiem tra.");
    }

    // ---------- helpers ----------
    static Color Hex(string h) { ColorUtility.TryParseHtmlString("#" + h, out var c); return c; }

    static RectTransform Rect(string name, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        return (RectTransform)go.transform;
    }

    static void Anchor(RectTransform r, float x0, float y0, float x1, float y1)
    {
        r.anchorMin = new Vector2(x0, y0); r.anchorMax = new Vector2(x1, y1);
        r.offsetMin = r.offsetMax = Vector2.zero;
    }

    static Sprite Spr(string key)
    {
        return string.IsNullOrEmpty(key) ? null : AssetDatabase.LoadAssetAtPath<Sprite>(SpriteDir + key + ".png");
    }

    static Image Img(GameObject go, Color col, string key)
    {
        var img = go.AddComponent<Image>();
        var s = Spr(key);
        if (s != null) { img.sprite = s; img.color = Color.white; img.type = Image.Type.Sliced; img.preserveAspect = false; }
        else img.color = col;
        return img;
    }

    static RectTransform Panel(string name, Transform p, Color col, float x0, float y0, float x1, float y1, string key = null)
    {
        var r = Rect(name, p); Anchor(r, x0, y0, x1, y1); Img(r.gameObject, col, key);
        r.GetComponent<Image>().raycastTarget = name != "Background" && name != "Ground";
        return r;
    }

    static Text Label(Transform p, string txt, int size, Color col, TextAnchor a, float x0, float y0, float x1, float y1, string name)
    {
        var r = Rect(name, p); Anchor(r, x0, y0, x1, y1);
        var t = r.gameObject.AddComponent<Text>();
        t.font = _font; t.text = txt; t.fontSize = size; t.color = col; t.alignment = a;
        t.resizeTextForBestFit = true; t.resizeTextMinSize = 12; t.resizeTextMaxSize = size;
        t.raycastTarget = false;
        return t;
    }

    static Button Btn(Transform p, string name, string txt, Color col, float x0, float y0, float x1, float y1, string key)
    {
        var r = Rect(name, p); Anchor(r, x0, y0, x1, y1);
        Img(r.gameObject, col, key);
        var b = r.gameObject.AddComponent<Button>();
        Label(r, txt, 40, White, TextAnchor.MiddleCenter, 0.05f, 0.05f, 0.95f, 0.95f, "Text");
        return b;
    }

    static RectTransform Character(Transform parent, string name, string caption, Color col, float ax, float size, string key)
    {
        var r = Rect(name, parent);
        r.anchorMin = r.anchorMax = new Vector2(ax, 0.42f);
        r.sizeDelta = new Vector2(size, size);
        Img(r.gameObject, col, key).raycastTarget = false;
        Label(r, caption, 32, White, TextAnchor.MiddleCenter, 0, 0, 1, 1, "Caption");

        var bar = Rect("HpBar", r);
        bar.anchorMin = new Vector2(0, 1); bar.anchorMax = new Vector2(1, 1); bar.pivot = new Vector2(0.5f, 0);
        bar.sizeDelta = new Vector2(0, 22); bar.anchoredPosition = new Vector2(0, 12);
        Img(bar.gameObject, BarBg, null).raycastTarget = false;
        var fill = Rect("Fill", bar);
        Anchor(fill, 0, 0, 1, 1);
        fill.offsetMin = new Vector2(3, 3); fill.offsetMax = new Vector2(-3, -3);
        Img(fill.gameObject, name == "Hero" ? Hex("7CFC8A") : Hex("FF7A7A"), null).raycastTarget = false;
        return fill;
    }

    static GearSlot NewSlot(Transform parent, string name, bool isInv)
    {
        var r = Rect(name, parent);
        Img(r.gameObject, SlotCol, "slot");
        var s = r.gameObject.AddComponent<GearSlot>(); s.isInventory = isInv;
        return s;
    }

    static void NewGear(GearSlot slot, int level, Color col)
    {
        var r = Rect("Gear_Lv" + level, slot.transform);
        Anchor(r, 0, 0, 1, 1); r.offsetMin = new Vector2(6, 6); r.offsetMax = new Vector2(-6, -6);
        Img(r.gameObject, col, "gear_" + level);
        r.gameObject.AddComponent<CanvasGroup>();
        var g = r.gameObject.AddComponent<GearItem>(); g.level = level;
        Label(r, "Lv" + level, 36, White, TextAnchor.MiddleCenter, 0, 0, 1, 1, "Level");
    }
}
#endif
