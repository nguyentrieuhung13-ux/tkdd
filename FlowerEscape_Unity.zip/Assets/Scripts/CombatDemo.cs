using UnityEngine;
using UnityEngine.UI;

/// <summary>Combat mau: gear tren luoi cang manh thi sat thuong cang cao. Chi de demo UI.</summary>
public class CombatDemo : MonoBehaviour
{
    public GameUIController ui;
    public RectTransform heroFill;
    public RectTransform[] enemyFills;
    public Text stageLabel, powerLabel, coinLabel;

    int _stage = 1, _coins;
    float _heroHp = 1f, _timer;
    float[] _enemyHp;

    void Start()
    {
        _enemyHp = new float[enemyFills.Length];
        ResetEnemies();
        GearSlot.Changed += Refresh;
        Refresh();
    }
    void OnDestroy() { GearSlot.Changed -= Refresh; }

    void ResetEnemies() { for (int i = 0; i < _enemyHp.Length; i++) _enemyHp[i] = 1f; }

    void Update()
    {
        if (ui == null || ui.State != GameState.Combat) return;
        _timer += Time.deltaTime;
        if (_timer < 0.8f) return;
        _timer = 0;

        int target = -1;
        for (int i = 0; i < _enemyHp.Length; i++) if (_enemyHp[i] > 0) { target = i; break; }
        if (target >= 0) _enemyHp[target] = Mathf.Max(0, _enemyHp[target] - (0.04f + GearSlot.BoardPower() * 0.02f));
        _heroHp = Mathf.Max(0.05f, _heroHp - 0.02f); // hero khong chet trong demo

        if (target >= 0 && _enemyHp[target] <= 0) _coins += 10;
        if (target < 0 || System.Array.TrueForAll(_enemyHp, h => h <= 0)) { _stage++; _heroHp = 1f; ResetEnemies(); }
        Refresh();
    }

    void Refresh()
    {
        if (heroFill) SetFill(heroFill, _heroHp);
        if (_enemyHp != null) for (int i = 0; i < enemyFills.Length; i++) SetFill(enemyFills[i], _enemyHp[i]);
        if (stageLabel) stageLabel.text = "MAN " + _stage;
        if (powerLabel) powerLabel.text = "Luc gear: " + GearSlot.BoardPower();
        if (coinLabel) coinLabel.text = _coins.ToString();
    }

    static void SetFill(RectTransform r, float v) { r.anchorMax = new Vector2(Mathf.Clamp01(v), 1f); }
}
