using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>Mot gear co the keo tha giua o inventory va o tren luoi.</summary>
public class GearItem : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public int level = 1;
    [HideInInspector] public GearSlot CurrentSlot;

    GearSlot _origin;
    CanvasGroup _cg;
    Canvas _canvas;

    void Awake() { _cg = gameObject.GetComponent<CanvasGroup>(); if (!_cg) _cg = gameObject.AddComponent<CanvasGroup>(); }

    public void OnBeginDrag(PointerEventData e)
    {
        _canvas = GetComponentInParent<Canvas>().rootCanvas;
        _origin = CurrentSlot;
        GearSlot.RememberOrigin(this, _origin);
        if (CurrentSlot != null) { CurrentSlot.Current = null; CurrentSlot = null; GearSlot.RaiseChanged(); }
        transform.SetParent(_canvas.transform, true);
        transform.SetAsLastSibling();
        _cg.blocksRaycasts = false;
    }

    public void OnDrag(PointerEventData e) { transform.position = e.position; }

    public void OnEndDrag(PointerEventData e)
    {
        _cg.blocksRaycasts = true;
        // Neu chua duoc tha vao slot nao -> tra ve cho cu
        if (CurrentSlot == null && _origin != null) _origin.Place(this);
    }
}
