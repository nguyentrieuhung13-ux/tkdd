using UnityEngine;
using UnityEngine.UI;

/// <summary>Tinh kich thuoc o vuong de luoi cols x rows luon vua khung o moi ti le man hinh.</summary>
[RequireComponent(typeof(GridLayoutGroup))]
public class GearBoard : MonoBehaviour
{
    public int cols = 4, rows = 3;
    public float spacing = 12f;
    GridLayoutGroup _grid;

    void OnEnable() { Fit(); }
    void OnRectTransformDimensionsChange() { Fit(); }
    void Update() { Fit(); }

    void Fit()
    {
        if (!_grid) _grid = GetComponent<GridLayoutGroup>();
        var r = ((RectTransform)transform).rect;
        if (r.width <= 1 || r.height <= 1) return;
        float w = (r.width - spacing * (cols - 1)) / cols;
        float h = (r.height - spacing * (rows - 1)) / rows;
        float c = Mathf.Max(10f, Mathf.Floor(Mathf.Min(w, h)));
        _grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
        _grid.constraintCount = cols;
        _grid.spacing = new Vector2(spacing, spacing);
        _grid.cellSize = new Vector2(c, c);
        _grid.childAlignment = TextAnchor.MiddleCenter;
    }
}
