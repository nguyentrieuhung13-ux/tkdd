using UnityEngine;

/// <summary>Co RectTransform theo Screen.safeArea (tai tho, notch, camera duc lo).</summary>
[RequireComponent(typeof(RectTransform))]
public class SafeAreaFitter : MonoBehaviour
{
    RectTransform _rt;
    Rect _last;
    Vector2Int _lastRes;

    void OnEnable() { _rt = GetComponent<RectTransform>(); Apply(); }
    void Update()
    {
        if (_last != Screen.safeArea || _lastRes.x != Screen.width || _lastRes.y != Screen.height) Apply();
    }

    void Apply()
    {
        if (_rt == null) _rt = GetComponent<RectTransform>();
        var sa = Screen.safeArea;
        _last = sa; _lastRes = new Vector2Int(Screen.width, Screen.height);
        if (Screen.width <= 0 || Screen.height <= 0) return;
        var min = sa.position; var max = sa.position + sa.size;
        min.x /= Screen.width; min.y /= Screen.height;
        max.x /= Screen.width; max.y /= Screen.height;
        _rt.anchorMin = min; _rt.anchorMax = max;
        _rt.offsetMin = _rt.offsetMax = Vector2.zero;
    }
}
