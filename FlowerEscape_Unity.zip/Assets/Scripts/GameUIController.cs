using UnityEngine;
using UnityEngine.UI;

public enum GameState { Combat, GearArrange }

/// <summary>
/// Chuyen trang thai man gameplay (Combat / Xep gear) va chia lai bo cuc
/// theo ti le man hinh (9:21 -> 3:4).
/// </summary>
public class GameUIController : MonoBehaviour
{
    [Header("Layout")]
    public RectTransform combatArea;
    public RectTransform bottomPanel;
    public GameObject combatPanel;
    public GameObject gearPanel;
    [Header("Buttons")]
    public Button openGearButton;
    public Button doneGearButton;
    public Button clearGearButton;
    public Text stateLabel;

    public GameState State { get; private set; }

    const float AspectTall = 9f / 21f;  // 0.4286
    const float AspectWide = 3f / 4f;   // 0.75
    const float HudBottom = 0.93f;      // top HUD chiem 7% tren cung

    float _bottomTop;

    void Awake()
    {
        if (openGearButton) openGearButton.onClick.AddListener(() => SetState(GameState.GearArrange));
        if (doneGearButton) doneGearButton.onClick.AddListener(() => SetState(GameState.Combat));
        if (clearGearButton) clearGearButton.onClick.AddListener(GearSlot.ReturnAllToInventory);
        SetState(GameState.Combat);
        _bottomTop = TargetTop();
        Apply();
    }

    public void SetState(GameState s)
    {
        State = s;
        if (combatPanel) combatPanel.SetActive(s == GameState.Combat);
        if (gearPanel) gearPanel.SetActive(s == GameState.GearArrange);
        if (stateLabel) stateLabel.text = s == GameState.Combat ? "CHIEN DAU" : "XEP GEAR";
    }

    float TargetTop()
    {
        float aspect = Screen.height > 0 ? (float)Screen.width / Screen.height : AspectTall;
        float t = Mathf.InverseLerp(AspectTall, AspectWide, aspect);
        return State == GameState.Combat
            ? Mathf.Lerp(0.26f, 0.32f, t)   // panel duoi khi combat
            : Mathf.Lerp(0.54f, 0.68f, t);  // man 3:4 can nhieu cao hon cho luoi gear
    }

    void Update()
    {
        _bottomTop = Mathf.Lerp(_bottomTop, TargetTop(), 1f - Mathf.Exp(-12f * Time.unscaledDeltaTime));
        Apply();
    }

    void Apply()
    {
        if (bottomPanel)
        {
            bottomPanel.anchorMin = Vector2.zero;
            bottomPanel.anchorMax = new Vector2(1f, _bottomTop);
            bottomPanel.offsetMin = bottomPanel.offsetMax = Vector2.zero;
        }
        if (combatArea)
        {
            combatArea.anchorMin = new Vector2(0f, _bottomTop);
            combatArea.anchorMax = new Vector2(1f, HudBottom);
            combatArea.offsetMin = combatArea.offsetMax = Vector2.zero;
        }
    }
}
