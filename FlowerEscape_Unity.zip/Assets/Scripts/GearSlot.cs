using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>O chua gear. isInventory=true la o trong kho, false la o tren luoi xep.</summary>
public class GearSlot : MonoBehaviour, IDropHandler
{
    public bool isInventory;
    [HideInInspector] public GearItem Current;

    public static event Action Changed;
    public static readonly List<GearSlot> All = new List<GearSlot>();
    public static void RaiseChanged() { Changed?.Invoke(); }

    void Awake()
    {
        var g = GetComponentInChildren<GearItem>();
        if (g != null) { Current = g; g.CurrentSlot = this; }
    }
    void OnEnable() { All.Add(this); }
    void OnDisable() { All.Remove(this); }

    public void Place(GearItem g)
    {
        g.transform.SetParent(transform, false);
        var rt = (RectTransform)g.transform;
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = new Vector2(6, 6); rt.offsetMax = new Vector2(-6, -6);
        rt.localScale = Vector3.one;
        Current = g; g.CurrentSlot = this;
        RaiseChanged();
    }

    public void OnDrop(PointerEventData e)
    {
        var g = e.pointerDrag ? e.pointerDrag.GetComponent<GearItem>() : null;
        if (g == null) return;
        var other = Current;
        Current = null;
        // g da bi roi khoi slot cu luc BeginDrag; slot cu chinh la noi other se ve
        var origin = OriginOf(g);
        Place(g);
        if (other != null && other != g)
        {
            if (origin != null) origin.Place(other);
            else FirstFreeInventory()?.Place(other);
        }
    }

    static readonly Dictionary<GearItem, GearSlot> _origins = new Dictionary<GearItem, GearSlot>();
    static GearSlot OriginOf(GearItem g) { _origins.TryGetValue(g, out var s); return s; }
    public static void RememberOrigin(GearItem g, GearSlot s) { _origins[g] = s; }

    static GearSlot FirstFreeInventory()
    {
        foreach (var s in All) if (s.isInventory && s.Current == null) return s;
        return null;
    }

    public static void ReturnAllToInventory()
    {
        foreach (var s in new List<GearSlot>(All))
        {
            if (s.isInventory || s.Current == null) continue;
            var free = FirstFreeInventory();
            if (free == null) return;
            free.Place(s.Current);
            s.Current = null;
        }
        RaiseChanged();
    }

    public static int BoardPower()
    {
        int p = 0;
        foreach (var s in All) if (!s.isInventory && s.Current != null) p += s.Current.level;
        return p;
    }
}
